## 5.0.0 — Central de streaming integrada
- Restaura o seletor de navegador do easiea ao abrir o Help HTML e arquivos HTML.
- Usa o `easiea` enviado como base, preservando melhorias de seleção, exportação, manutenção e diagnóstico.
- Integra o `eazy-yt-stream` com pesquisa persistente, histórico de filmes assistidos, pergunta de favorito ao terminar, favoritos, duração dos vídeos e paginação de 30 resultados.
- Inclui o stream, IA, editor de notas, eazy-tor, man page e help no instalador e no pacote Debian.
- Remove o caminho fixo `/home/jim` do empacotamento e mantém os componentes em `/usr/bin` e `/usr/lib/eazy`.
- Atualiza `update-all`, modo Dev, documentação, man/help e instalador web.

## 3.2.10 — Enter py/sh/html com menu (estilo PDF)
- Ramo principal do Enter chama menu_arquivo_* para py, sh e html

## 3.2.9 — Menus numerados
## 3.2.8 — Alt-X qtd/bytes
## 3.2.7 — SHELL_CMD e menus sh/html
## 3.2.6 — PYTHON_CMD
